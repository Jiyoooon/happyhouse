package com.ssafy.happyhouse;
 
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HappyHouseWebSpringSeoul10KimOhApplication {

	public static void main(String[] args) {
		SpringApplication.run(HappyHouseWebSpringSeoul10KimOhApplication.class, args);
	}

}
