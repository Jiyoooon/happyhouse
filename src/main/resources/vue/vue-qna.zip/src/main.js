import Vue from "vue";
import App from "@/components/App.vue"; //router 시작 페이지
import router from "./router";
import VueSession from 'vue-session';

Vue.use(VueSession);
Vue.config.productionTip = false;

new Vue({
  router,
  VueSession,
  render: h => h(App)
}).$mount("#app");
