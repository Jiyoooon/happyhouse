import Vue from "vue";
import VueRouter from "vue-router";

// 라우트 컴포넌트
import App from '@/components/App.vue';
import Create from '@/components/Create.vue';
import Delete from '@/components/Delete.vue';
import List from '@/components/List.vue';
import Read from '@/components/Read.vue';
import Update from '@/components/Update.vue';

Vue.use(VueRouter);

const router = new VueRouter({
  mode: "history",
  routes: [
      {
        path: '/'
        , name: 'qna'
        , component: App
        , redirect: '/happyhouse/qna.do'
      }
      , {
          path: '/happyhouse/qna'
          , name: 'qna'
          , component: App
          , redirect: '/happyhouse/qna.do'
      }
      , {
          path: '/happyhouse/qna.do'
          , name: 'qnalist'
          , component: List
      }
      , {
        path: '/happyhouse/qna/detail/:no'
        , name: 'qnadetail'
        , component: Read
      }
      , {
        path: '/happyhouse/qna/create'
        , name: 'qnacreate'
        , component: Create
      }
      , {
        path: '/happyhouse/qna/delete/:no'
        , name: 'qnadelete'
        , component: Delete
      }
      , {
        path: '/happyhouse/qna/update/:no'
        , name: 'qnaupdate'
        , component: Update
      }
  ]
});

export default router;
