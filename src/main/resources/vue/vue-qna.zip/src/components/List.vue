<template>
    <div  class=wrapper align="center"  >
              	<div class=col-lg-6 align="center">

      <div v-if="items.length">
        <table class="table table-bordered table-condensed">
          <colgroup>
            <col :style="{width: '10%'}" />
            <col :style="{width: '50%'}" />
            <col :style="{width: '15%'}" />
            <col :style="{width: '25%'}" />
          </colgroup>
          <tr>
            <th>번호</th>
            <th>제목</th>
            <th>작성자</th>
            <th>날짜</th>
          </tr>
          <tr v-for="(qna, index) in items" :key="index + '_items'">
            <td>{{qna.qna_no}}</td>
            <td><router-link :to="{name: 'qnadetail', params: {no: qna.qna_no}}">{{qna.qna_title}}</router-link></td>
            <td>{{qna.qna_userid}}</td>
            <td>{{qna.qna_datetime}}</td>
          </tr>
        </table>
      </div>
      <div v-else class="text-center">
        게시글이 없습니다.
      </div>
      <div class="text-right">
        <router-link v-if="checkUser()" :to="{name:'qnacreate'}" class="btn btn-primary">등록</router-link>
      </div>
              	</div>
    </div>
</template>

<script>
    import http from '@/util/http-common.js'; 
    import axios from 'axios';

    export default {
        name: 'List',
        data: function () {
            return {
              items: [],
              user:'',
            };
        }
        , created() {
            http.get().then(({ data }) => {
              console.log(data);
              
              this.items = data;
            });
            axios.get('http://localhost:9000/happyhouse/api/qna/userinfo').then(({ data }) => {
                console.log(data);
                 this.user = data;
             });
        },
        methods:{
          checkUser(){
                // return true;
                console.log(this.user);
                if(this.user.userid != null) return true;
                else return false;
            },
        }
    }
</script>

<style lang="scss" scoped>

</style>