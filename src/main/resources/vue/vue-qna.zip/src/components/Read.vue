<template>
    <div class=wrapper align="center">
        	<div class=col-lg-6 align="center">

        <table class="table table-bordered w-50">
            <tr>
                <th>번호</th>
                <td>{{item.qna_no}}</td>
            </tr>
            <tr>
                <th>글쓴이</th>
                <td>{{item.qna_userid}}</td>
            </tr>
            <tr>
                <th>제목</th>
                <td>{{item.qna_title}}</td>
            </tr>
            <tr>
                <th>날짜</th>
                <td>{{item.qna_datetime}}</td>
            </tr>
            <tr>
                <td colspan="2">
                    {{item.qna_content}}
                </td>
            </tr>
        </table>
            <hr>
        <table v-if="item.reply_userid != null" class="table table-bordered w-50">
            <tr>
                <th>작성자</th>
                <td>{{item.reply_userid}}</td>
            </tr>
            <tr>
                <th>날짜</th>
                <td>{{item.reply_datetime}}</td>
            </tr>
            <tr>
                <td colspan="2">
                    {{item.reply_content}}
                </td>
            </tr>
        </table>
        <br />
        <div class="text-center">
            <router-link :to="{name: 'qnalist'}" class="btn btn-primary">목록</router-link>
            <router-link v-if="checkUser()" :to="{name: 'qnaupdate', params: {no: item.qna_no}}" class="btn btn-primary">수정</router-link>
            <router-link v-if="checkUser()" :to="{name: 'qnadelete', params: {no: item.qna_no}}" class="btn btn-primary">삭제</router-link>
            <!-- 관리자라면 reply 하는 기능 -->
        <div>
            <textarea  name="reply" rows = "4" cols="50" v-model="reply_content"/>
            <button class="btn btn-primary" v-if="checkAdmin()" @click="replyCreate">답글등록</button>
        </div>
        
        </div>
        	</div>
    </div>
</template>

<script>
    import http from '@/util/http-common.js';
    import axios from 'axios';
    export default {
        name: 'Read',
        data: function () {
            return {
                item: {},
                user:'',
                qna_no:'',
                qna_title:'',
                qna_content:'',
                qna_userid:'',
                reply_content:'',
                reply_datetime:'',
                reply_userid:'',
                isadmin:''
            };
        },
        created() {
            
            http.get(`/${this.$route.params.no}`).then(({ data }) => {
                this.item = data;
            });
            axios.get('http://localhost:9000/happyhouse/api/qna/userinfo').then(({ data }) => {
                console.log(data);
                 this.user = data;
             });
            
        },
        methods: {
            checkUser(){
                // return true;
                // console.log(this.user);
                if(this.user != null && this.user.userid == this.item.qna_userid) return true;
                else return false;
            },
            checkAdmin(){
                // return true;
                // console.log(this.user);
                if(this.user.isAdmin ==true) return true;
                else return false;
            },
            replyCreate(){
                let err = true;
                let msg = '';
                 !this.reply_content &&
                    ((msg = '내용 입력해주세요'), (err = false), this.$refs.content.focus());

                if (!err) alert(msg);
                else this.createHandler();
            },
            createHandler(){
               http
                .put(`${this.$route.params.no}`, {
                    qna_no: this.item.qna_no,
                    qna_title:this.item.qna_title,
                    qna_content:this.item.qna_content,
                    qna_userid:this.item.qna_userid,
                    reply_content: this.reply_content,
                    // reply_datetime:"now()",
                    reply_userid: this.user.userid
                })
                .then(({ data }) => {
                    let msg = '댓글등록 처리시 문제가 발생했습니다.';
                    if (data ==='success') {
                        msg = '등록이 완료되었습니다.';
                    }
                    alert(msg);
                    this.$router.push({name: 'qnalist'});
                });
            },
            moveList() {
                this.$router.push({name:'qnadetail'});
            },
        }
    }
</script>

<style lang="scss" scoped>

</style>