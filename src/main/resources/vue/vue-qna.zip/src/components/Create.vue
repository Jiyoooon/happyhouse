<template>
    <div class=wrapper align="center">
        	<div class=col-lg-6 align="center">
        <div class="form-group">
            <label for="writer">작성자</label>
            <input type="text" class="form-control" id="userid" ref="userid" placeholder="작성자를 입력하세요" v-model="qna_userid">
        </div>
        <div class="form-group">
            <label for="title">제목</label>
            <input type="text" class="form-control" id="title" ref="title" placeholder="제목을 입력하세요" v-model="qna_title">
        </div>
        <div class="form-group">
            <label for="content">내용</label>
            <textarea type="text" class="form-control" id="contnet" ref="content" placeholder="내용을 입력하세요"
                v-model="qna_content"></textarea>
        </div>
        <div class="text-right">
            <button class="btn btn-primary" @click="checkHandler">등록</button>
            <button class="btn btn-primary" @click="moveList">목록</button>
        </div>
        	</div>
    </div>
</template>

<script>
    import axios from 'axios';
    import http from '@/util/http-common.js';
    export default {
        name: 'Create',
        data: function () {
            return {
                qna_userid: '',
                qna_title: '',
                qna_content: '',
                curUser: ''
            };
        },
        created(){
            axios.get('http://localhost:9000/happyhouse/userinfo').then(({data}) => {
                console.log(data);
                if(data.login == 'yes'){
                    this.curUser = data.curUser;
                }
            });
        },
        methods: {
            checkHandler() {
            let err = true;
            let msg = '';
            !this.qna_userid && ((msg = '작성자를 입력해주세요'), (err = false), this.$refs.userid.focus());
            err && !this.qna_title && ((msg = '제목 입력해주세요'), (err = false), this.$refs.title.focus());
            err &&
                !this.qna_content &&
                ((msg = '내용 입력해주세요'), (err = false), this.$refs.content.focus());

            if (!err) alert(msg);
            else this.createHandler();
            },
            createHandler() {
            http
                .post('', {
                    qna_userid: this.qna_userid,
                    qna_title: this.qna_title,
                    qna_content: this.qna_content
                })
                .then(({ data }) => {
                    let msg = '등록 처리시 문제가 발생했습니다.';
                    if (data === 'success') {
                        msg = '등록이 완료되었습니다.';
                }
                alert(msg);
                this.moveList();
                });
            },
            moveList() {
                this.$router.push({name:'qnalist'});
            },
        }
    }
</script>

<style lang="scss" scoped>

</style>