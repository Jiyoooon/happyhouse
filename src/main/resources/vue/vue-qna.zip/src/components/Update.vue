<template>
   <div class=wrapper align="center">
        	<div class=col-lg-6 align="center">
        <div class="form-group">
            <label for="writer">작성자</label>
            <input type="text" class="form-control" id="userid" ref="userid" v-model="qna_userid">
        </div>
        <div class="form-group">
            <label for="title">제목</label>
            <input type="text" class="form-control" id="title" ref="title" placeholder="제목을 입력하세요" v-model="qna_title">
        </div>
        <div class="form-group">
            <label for="content">내용</label>
            <textarea type="text" class="form-control" id="contnet" ref="content" placeholder="내용을 입력하세요"
            v-model="qna_content"></textarea>
        </div>
        <div class="text-right">

            <button class="btn btn-primary" @click="checkHandler">수정</button>
        </div>
        	</div>
    </div>
</template>

<script>
    import http from '@/util/http-common.js';
    export default {
        name: 'Update',
        data: function () {
            return {
                qna_no: '',
                qna_datetime: '',
                qna_userid: '',
                qna_title: '',
                qna_content: ''
            };
        },
        methods: {
            checkHandler() {
            let err = true;
            let msg = '';
            !this.qna_userid && ((msg = '작성자를 입력해주세요'), (err = false), this.$refs.userid.focus());
            err && !this.qna_title && ((msg = '제목 입력해주세요'), (err = false), this.$refs.title.focus());
            err &&
                !this.qna_content &&
                ((msg = '내용 입력해주세요'), (err = false), this.$refs.content.focus());

            if (!err) alert(msg);
            else this.updateHandler();
            },
            updateHandler() {
            http
                .put(`${this.$route.params.no}`, {
                    qna_no: this.qna_no,
                    qna_datetime: this.qna_datetime,
                    qna_userid: this.qna_userid,
                    qna_title: this.qna_title,
                    qna_content: this.qna_content
                })
                .then(({ data }) => {
                    let msg = '수정 처리시 문제가 발생했습니다.';
                    if (data === 'success') {
                        msg = '수정이 완료되었습니다.';
                    }
                    alert(msg);
                    this.$router.push({name: 'qnalist'});
                });
            },
        },
        created() {
            http.get(`${this.$route.params.no}`).then(({ data }) => {
                this.qna_no = data.qna_no;
                this.qna_datetime = data.qna_datetime;
                this.qna_userid = data.qna_userid;
                this.qna_title = data.qna_title;
                this.qna_content = data.qna_content;
            });
        }
    }
</script>

<style lang="scss" scoped>

</style>